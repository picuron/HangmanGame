
public class runHangman {
	public static void main (String[] args) {
		Hangman h1 = new Hangman();
	}
}
