import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;
import javax.swing.*;


public class Hangman extends JFrame implements ActionListener {
	String word;
	int wordLength;
	int wrongCounter;
	char[] wordArray;
	char[] blankArray;
	private JFrame myFrame;
    private JPanel gameboardPanel; //create a panel to add to JFRAME
    private JPanel gameMenu;
    private JButton playButton;
    private JButton enterButton;
    private JTextArea startText;
    private JTextArea title;
    private JTextArea wordSpace;
    private JTextArea yourWordText;
    private JTextField enterText;
    private JTextField enterLetter;
    private BufferedImage image0, image1, image2, image3, image4, image5, image6;
    private JLabel image0label, image1label, image2label, image3label, image4label, image5label, image6label;
    
	//User gives a word
	Hangman(){
		//Construct board
		myFrame = new JFrame("Slider Game");
        myFrame.setSize(500,500);
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        gameboardPanel = new JPanel();
        gameboardPanel.setEnabled(false);
        gameboardPanel.setBounds(0, 0, 500, 400);
        gameboardPanel.setBackground(Color.white);
        
        gameMenu = new JPanel();
        gameMenu.setEnabled(false);
        gameMenu.setBounds(0, 400, 500, 100);
        gameMenu.setBackground(new Color(51,204,255));
        
        enterText = new JTextField("");
        enterText.setBounds(200, 415, 100, 25);
        myFrame.add(enterText);
        
        enterLetter = new JTextField("");
        enterLetter.setBounds(200, 415, 100, 25);
        myFrame.add(enterLetter);
        enterLetter.setVisible(false);
        
        //Button in start menu to start playing
        playButton = new JButton("Play!");
        playButton.setBounds(175, 450, 150, 25);
        playButton.addActionListener(this);
        myFrame.add(playButton);
       
        //Button present while playing to enter a word
        enterButton = new JButton("Enter");
        enterButton.setBounds(175, 450, 150, 25);
        enterButton.addActionListener(this);
        myFrame.add(enterButton);
        enterButton.setVisible(false);
       
        //Font for title
        Font font1 = new Font("SansSerif", Font.BOLD, 30);
        
        //Game title
        title = new JTextArea("Hangman");
        title.setFont(font1);
        gameboardPanel.add(title);
        title.setEditable(false);
        title.setVisible(true);
        
        //Rules
        startText = new JTextArea("Enter a word to use for the game in the textbox above the play button, 10 characters max. "
        		+ "Leave text field blank to use a random word, if playing alone." + "\n" + "\n" + "Rules" + "\n" 
        		+ "1: Words must be ten characters max" + "\n" + "2: Only use letters" + "\n" + "3: Only enter one letter at a time while playing");
        startText.setLineWrap(true);
        startText.setSize(400,200);
        startText.setEditable(false);
        gameboardPanel.add(startText);
        startText.setVisible(true);
        
        Font font2 = new Font("SansSerif", Font.BOLD, 22);
        
        yourWordText = new JTextArea("Your word: ");
        yourWordText.setFont(font2);
        yourWordText.setEditable(false);
        yourWordText.setBounds(5, 300, 125, 50);
        myFrame.add(yourWordText);
        yourWordText.setVisible(false);
        
        //Displays correct entered word
        wordSpace = new JTextArea();
        wordSpace.setFont(font2);
        wordSpace.setEditable(false);
        wordSpace.setBounds(150, 300, 350, 50);
        myFrame.add(wordSpace);
        wordSpace.setVisible(false);
       
        //Creates images, with included error trapping in case images don't import properly/runs into other issues
        try {                
        	 image0 = ImageIO.read(new File("0.png"));
        	 image0label = new JLabel(new ImageIcon(image0));
        	 gameboardPanel.add(image0label);
        	 image0label.setVisible(false);
        	 
        	 image1 = ImageIO.read(new File("1.png"));
        	 image1label = new JLabel(new ImageIcon(image1));
        	 gameboardPanel.add(image1label);
        	 image1label.setVisible(false);
        	 
        	 image2 = ImageIO.read(new File("2.png"));
        	 image2label = new JLabel(new ImageIcon(image2));
        	 gameboardPanel.add(image2label);
        	 image2label.setVisible(false);
        	 
        	 image3 = ImageIO.read(new File("3.png"));
        	 image3label = new JLabel(new ImageIcon(image3));
        	 gameboardPanel.add(image3label);
        	 image3label.setVisible(false);
        	 
        	 image4 = ImageIO.read(new File("4.png"));
        	 image4label = new JLabel(new ImageIcon(image4));
        	 gameboardPanel.add(image4label);
        	 image4label.setVisible(false);
        	 
        	 image5 = ImageIO.read(new File("5.png"));
        	 image5label = new JLabel(new ImageIcon(image5));
        	 gameboardPanel.add(image5label);
        	 image5label.setVisible(false);
        	 
        	 image6 = ImageIO.read(new File("6.png"));
        	 image6label = new JLabel(new ImageIcon(image6));
        	 gameboardPanel.add(image6label);
        	 image6label.setVisible(false);
         } catch (IOException ex) {
              System.out.println("Error 1: Images unable to appear. Please ensure all image files are downloaded");
         }
     
        myFrame.add(gameboardPanel);
		myFrame.add(gameMenu);
		//myFrame.add(gameboardPanel,BorderLayout.NORTH);
		//myFrame.add(gameMenu,BorderLayout.CENTER);
        
        gameboardPanel.setEnabled(true);
		gameMenu.setEnabled(true);
               
        myFrame.setVisible(true); 
	}
	
	//When user begins game
	public void playGame() {
		enterText.setVisible(true);
		playButton.setVisible(false);
		enterButton.setVisible(true);
		startText.setVisible(false);
		title.setVisible(false);
		enterText.setVisible(false);
		enterLetter.setVisible(true);
		image0label.setVisible(true);
		yourWordText.setVisible(true);
	
		wordLength = word.length();
		
		//Makes array correct length
		wordArray = new char[wordLength];
		blankArray = new char[wordLength];
		
		//Sets up array with correct letters in it, as well as blank array
		for(int i = 0; i < wordLength; i++) {
			wordArray[i] = word.charAt(i);
			blankArray[i] = '-';
			
		}
		//Displays blank array
		wordSpace.setText(Arrays.toString(blankArray)); 
		wordSpace.setVisible(true);
	}
	
	//When user enters a letter
	public void letterEntered() {
		String enteredWord = enterLetter.getText();
		enterLetter.setText("");
		char input = enteredWord.charAt(0);
		System.out.println(input);
		
		boolean wordChanged = false;
		boolean hasWon = false;
		
		//Checks if inputed character is part of word
		for (int i = 0; i < wordLength; i++) {
			//Adds word to blankArray if character is part of word
			if(input == wordArray[i]) {
				blankArray[i] = input;
				wordSpace.setText(Arrays.toString(blankArray)); 
				wordChanged = true;
			}
		}
		
		//Changes image if user gets wrong word
		if(wordChanged == false) {
			wrongCounter++;
			System.out.println(wrongCounter);
			if(wrongCounter == 1) {
				image0label.setVisible(false);
				image1label.setVisible(true);
			}
			if(wrongCounter == 2) {
				image1label.setVisible(false);
				image2label.setVisible(true);
			}
			if(wrongCounter == 3) {
				image2label.setVisible(false);
				image3label.setVisible(true);
			}
			if(wrongCounter == 4) {
				image3label.setVisible(false);
				image4label.setVisible(true);
			}
			if(wrongCounter == 5) {
				image4label.setVisible(false);
				image5label.setVisible(true);
			}
			if(wrongCounter == 6) {
				image5label.setVisible(false);
				image6label.setVisible(true);
			}
			if(wrongCounter == 7) {
				image6label.setVisible(false);
				youLose();
			}
		}
		
		//Check to see if user won
		if(wordChanged == true) {
			hasWon = true;
			for (int i = 0; i < wordLength; i++) {
				if(blankArray[i] == '-') {
					hasWon = false;
				}
			}
			if (hasWon == true) {
				youWin();
			}
		}
	}
	
	private void youLose() {
		title.setVisible(true);
		startText.setText("Sorry, you lost! Restart the game to try again! The word was: " + word);
		Font font2 = new Font("SansSerif", Font.BOLD, 22);
		startText.setFont(font2);
		startText.setVisible(true);
		yourWordText.setVisible(false);
		wordSpace.setVisible(false);
		
	}
	
	private void youWin() {
		image0label.setVisible(false);
		image1label.setVisible(false);
		image2label.setVisible(false);
		image3label.setVisible(false);
		image4label.setVisible(false);
		image5label.setVisible(false);
		image6label.setVisible(false);
		title.setVisible(true);
		startText.setText("Great job, you won! Restart the game to play again.");
		Font font2 = new Font("SansSerif", Font.BOLD, 22);
		startText.setFont(font2);
		startText.setVisible(true);
		yourWordText.setVisible(false);
		wordSpace.setVisible(false);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == playButton) {
			word = enterText.getText();
			
			//Catch if text field is blank
			if(word.equals("")) {
				//Error trapping to ensure hangmanText is downloaded.
				try {
					FileReader fr = new FileReader("hangmanText.txt");
					BufferedReader randomWords = new BufferedReader(fr);	
					 
					int randomNum = 2 + (int)(Math.random() * 50);
					for(int i = 0; i < randomNum; i++) {
						word = "";
						word = randomWords.readLine();
					}
					randomWords.close();
				} catch (FileNotFoundException e1) {
					System.out.println("Error 2: Unable to locate hangmanText text file. Ensure file is downloaded");
		
				} catch (IOException e1) {
					System.out.println("Error 3: File read/write issue");
					
				}
		        
			}
			//System.out.println(word);
			playGame();
		}
		
		if(e.getSource() == enterButton) {	
			letterEntered();	
		}
	}
}
